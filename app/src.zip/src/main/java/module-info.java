module org.nomanspace.electricitymeters {
    requires java.base;
    requires java.desktop;

    exports org.nomanspace.electricitymeters;
    exports org.nomanspace.electricitymeters.path;
}