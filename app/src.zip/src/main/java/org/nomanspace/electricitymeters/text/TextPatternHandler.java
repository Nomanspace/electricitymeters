package org.nomanspace.electricitymeters.text;

public interface TextPatternHandler {

    String process(String input);
}
