package org.nomanspace.electricitymeters.path;

import java.nio.file.Path;

public interface PathProvider {
    Path providePath();
} 
