package org.nomanspace.electricitymeters.text;

public class DatFileParseHandler implements TextPatternHandler{

    @Override
    public String process(String input) {
        
        return "";
    }
}
